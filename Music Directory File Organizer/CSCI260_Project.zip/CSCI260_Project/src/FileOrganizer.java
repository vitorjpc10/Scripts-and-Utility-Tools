/* The focus of this class is to read all the files in the music folder, instantiate sub-folders within it, 
 * and place all the files that correlate to that folder category inside the sub-folder.
 * 
 * The MusicFolderOriginal folder consists of all of the original dummy data we are using for testing purposes
 * The MusicFolder is the folder we are using to organize the files and instantiate sub-folders in it in order to place the files in their corresponding sub-folder
 * 
 * AFTER EACH RUN DELETE ALL THE FILES FROM THE MusicFolder AND COPY THE FILES FROM THE MusicFolderOriginal AND PLACE IT AT THE MusicFolder IN ORDER TO HAVE THE FileOrganizer
 * CLASS ORGANIZE THE FILES IN THE MusicFolder AGAIN.
 *  
 */

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import java.io.*; 
import java.nio.file.*; 


public class FileOrganizer 
{

	//This is a bubble sort method to sort a string array and return the string array in a alphabetical manner.
	public static void bubbleSort(String[] stringArray)
	{
		int n = stringArray.length;
		String temp = null;

		for(int i=0; i<n; i++)
		{
			for(int j=1; j< (n-i); j++)
			{
				if(stringArray[j-1].compareTo(stringArray[j]) >= 0)
				{
					temp = stringArray[j-1];
					stringArray[j-1] = stringArray[j];
					stringArray[j] = temp;
				}
			}
		}
	}


	public static void main(String args[]) throws IOException
	{

		//Creating a file for the folder where it contains all the musical dummy files
		File musicFolder = new File(".\\src\\MusicFolder");

				//File directory = new File("./");
		//System.out.println("The Path is: " + directory.getAbsolutePath());


		/*With the modified BT and BTNode class so that it accepts String values and stores it in the tree in a
		 * alphabetical manner, I am placing the  from the folder into the binary tree as it read the files from the 
		 * folder.  */
		BT bt = new BT();
 
		for(File file : musicFolder.listFiles())
		{
			bt.insert(file.getName());
		}

		System.out.println("Successfully stored in the Binary Tree Alphabetically \n");

		//store all files directories from the folder into an linkedList
		LinkedList<File> musicFiles = new LinkedList<File>();


		for(File file : musicFolder.listFiles())
		{
			musicFiles.add(file);
		}
	
		System.out.println("Successfully stored in a Linked List \n");
		
		//Creating an String array with all of the files in an alphabetically organized fashion
		String[] sortedMusicFiles = musicFolder.list();
		bubbleSort(sortedMusicFiles);
		
		//for(String fileName: sortedMusicFiles)
		//System.out.println("The Sorted Music Files is: " + fileName + "\n");
		
		System.out.println("Successfully created an alphabetically organized instance of a String Array using BubbleSort \n");
		

		//System.out.println(musicFiles);


		//create multiple  String arrays to look for files that have one of the names in the array
		// e.g. Scales (Abm, Cmaj, ... ), Instruments(guitar, bass, horns), Percursion (snare, hats,..)
		String[] scales = {"Major", "Minor", "Dorian"};
		String[] percussion = {"Snare", "Kick", "HiHat", "Cymbal"};
		String[] loops = {"Loop"};
		String[] instruments = {"Guitar", "Keys", "Bass", "Piano", "Conga","Harmonica"};

		System.out.println("Name checking arrays were instantiated \n");



		//start comparing file names from the arraylist and the array with the titles for a match
		//If matched
		//	1. create a stack under the name of the array category and store the file in the stack
		//	2. Put the file category name in a queue
		Queue<String> folderCategoryName = new LinkedList<String>();

		//Placing the file directories in the stack that correlates to its category type
		// e.g. .\src\MusicFolder\AbMajor.txt into the scalesMatched Stack
		Stack scalesMatched = new Stack();
		Stack percussionMatched = new Stack();
		Stack loopsMatched = new Stack();
		Stack instrumentsMatched = new Stack();
		Stack notMatched = new Stack();

		System.out.println("Stacks and Queues created \n");

		/* Using this flag to check if there was a match when comparing file name with the string arrays, 
		 * if there isn't one at the end of checking all string arrays then insert on the notMatched Stack and Queue */
		boolean match = false;

		// Just to make sure I'm not inserting multiple instances of the category name in the queue so that I can create only one folder of that type
		boolean scalesQueueInserted = false;
		boolean percussionQueueInserted = false;
		boolean loopsQueueInserted = false;
		boolean instrumentsQueueInserted = false;
		boolean notMatchedQueueInserted = false;

		File currentMusicFile;

		//This while loops will both the stacks and Queue created previously, it will go through the entire linkedList checking for the directory name and if there is a match 
		//then it stores it the respective stack where it falls under and adds the name of the category it falls under into the queue so that the folder for that category can be
		//instantiated later. 
		while(!musicFiles.isEmpty())
		{

			currentMusicFile = musicFiles.remove();

			//System.out.println(currentMusicFile.getName());


			for(String i : scales)
			{
				//System.out.println(currentMusicFile.getName());
				//System.out.println("Checking for " + i + ": " + currentMusicFile.getName().contains(i));

				if(currentMusicFile.getName().contains(i))
				{


					if(scalesQueueInserted == false)
					{
						folderCategoryName.add("Scales");
						scalesQueueInserted = true;
					}

					scalesMatched.add(currentMusicFile);
					match = true;
				}
			}

			for(String i : percussion)
			{
				//System.out.println(currentMusicFile.getName());
				//System.out.println("Checking for " + i + ": " + currentMusicFile.getName().contains(i));

				if(currentMusicFile.getName().contains(i))
				{
					if(percussionQueueInserted == false)
					{
						folderCategoryName.add("Percussion");
						percussionQueueInserted = true;
					}

					percussionMatched.add(currentMusicFile);
					match = true;
				}
			}

			for(String i : loops)
			{
				//System.out.println(currentMusicFile.getName());
				//System.out.println("Checking for " + i + ": " + currentMusicFile.getName().contains(i));

				if(currentMusicFile.getName().contains(i))
				{
					if(loopsQueueInserted == false)
					{
						folderCategoryName.add("Loops");
						loopsQueueInserted = true;
					}

					loopsMatched.add(currentMusicFile);
					match = true;
				}
			}

			for(String i : instruments)
			{
				//System.out.println(currentMusicFile.getName());
				//System.out.println("Checking for " + i + ": " + currentMusicFile.getName().contains(i));

				if(currentMusicFile.getName().contains(i))
				{
					if(instrumentsQueueInserted == false)
					{
						folderCategoryName.add("Instruments");
						instrumentsQueueInserted = true;
					}

					instrumentsMatched.add(currentMusicFile);
					match = true;
				}
			}

			if(match == false)
			{

				if(notMatchedQueueInserted == false)
				{
					folderCategoryName.add("Unable to Categorize");
					notMatchedQueueInserted = true;
				}

				notMatched.add(currentMusicFile);
			}



			match = false;
		}




		//Checking if was placed correctly
		/*
		 System.out.println("Category names are: ");
		while(!folderCategoryName.isEmpty())
		{	
			System.out.println(folderCategoryName.remove());

		}

		System.out.println("\n");


		System.out.println("Scales Stack is: " + scalesMatched + "\n");
		System.out.println("percussion Stack is: " +percussionMatched + "\n");
		System.out.println("Loops Stack is: " +loopsMatched + "\n");
		System.out.println("Instruments Stack is: " +instrumentsMatched + "\n");
		System.out.println("NotMatched Stack is: " +notMatched + "\n");
		 */





		//after analyzing the entire folder 
		//	1. Instantiate new folders on the location of the folder we are analyzing and name it after the categories that were matched and placed it in the queue (create while loop until queue is empty)
		//	2. empty the stack of that category in the folder

		//Creates the folder Directories with the category names being used to name the folders
		String folderName = null; 

		while(!folderCategoryName.isEmpty())
		{
			folderName = folderCategoryName.peek();

			File file = new File(".\\src\\MusicFolder\\" + folderCategoryName.remove());	

			boolean bool = file.mkdir();
			if(bool)
			{
				System.out.println("Directory " + folderName + " was created successfully");
			}
			else
			{
				System.out.println("Sorry couldn�t create specified directory");
			}
		}

		System.out.println("\n");

		//Empties the Stack of Scales and moves the files into the respective "scales" folder
		while(!scalesMatched.isEmpty())
		{

			String textFileName = scalesMatched.pop().toString().substring(18);

			Path temp = Files.move (Paths.get("C:\\Users\\vitor\\eclipse-workspace\\CSCI260_Project\\src\\MusicFolder\\" + textFileName), Paths.get("C:\\Users\\vitor\\eclipse-workspace\\CSCI260_Project\\src\\MusicFolder\\Scales\\" + textFileName)); 

			if(temp != null) 
			{ 
				System.out.println("The File " + textFileName + " was moved successfully"); 
			} 
			else
			{ 
				System.out.println("Failed to move the file"); 
			} 
		}



		//Empties the Stack of percussion and moves the files into the respective "percussion" folder
		while(!percussionMatched.isEmpty())
		{

			String textFileName = percussionMatched.pop().toString().substring(18);

			Path temp = Files.move (Paths.get("C:\\Users\\vitor\\eclipse-workspace\\CSCI260_Project\\src\\MusicFolder\\" + textFileName), Paths.get("C:\\Users\\vitor\\eclipse-workspace\\CSCI260_Project\\src\\MusicFolder\\percussion\\" + textFileName)); 

			if(temp != null) 
			{ 
				System.out.println("The File " + textFileName + " was moved successfully"); 
			} 
			else
			{ 
				System.out.println("Failed to move the file"); 
			} 

		}


		//Empties the Stack of Loops and moves the files into the respective "Loops" folder
		while(!loopsMatched.isEmpty())
		{

			String textFileName = loopsMatched.pop().toString().substring(18);

			Path temp = Files.move (Paths.get("C:\\Users\\vitor\\eclipse-workspace\\CSCI260_Project\\src\\MusicFolder\\" + textFileName), Paths.get("C:\\Users\\vitor\\eclipse-workspace\\CSCI260_Project\\src\\MusicFolder\\Loops\\" + textFileName)); 

			if(temp != null) 
			{ 
				System.out.println("The File " + textFileName + " was moved successfully"); 
			} 
			else
			{ 
				System.out.println("Failed to move the file"); 
			} 

		}

		//Empties the Stack of Instruments and moves the files into the respective "Intruments" folder
		while(!instrumentsMatched.isEmpty())
		{

			String textFileName = instrumentsMatched.pop().toString().substring(18);

			Path temp = Files.move (Paths.get("C:\\Users\\vitor\\eclipse-workspace\\CSCI260_Project\\src\\MusicFolder\\" + textFileName), Paths.get("C:\\Users\\vitor\\eclipse-workspace\\CSCI260_Project\\src\\MusicFolder\\Instruments\\" + textFileName)); 

			if(temp != null) 
			{ 
				System.out.println("The File " + textFileName + " was moved successfully"); 
			} 
			else
			{ 
				System.out.println("Failed to move the file"); 
			} 

		}

		//Empties the Stack of notMatched and moves the files into the respective "Unable to Categorize" folder
		while(!notMatched.isEmpty())
		{

			String textFileName = notMatched.pop().toString().substring(18);

			Path temp = Files.move (Paths.get("C:\\Users\\vitor\\eclipse-workspace\\CSCI260_Project\\src\\MusicFolder\\" + textFileName), Paths.get("C:\\Users\\vitor\\eclipse-workspace\\CSCI260_Project\\src\\MusicFolder\\Unable to Categorize\\" + textFileName)); 

			if(temp != null) 
			{ 
				System.out.println("The File " + textFileName + " was moved successfully"); 
			} 
			else
			{ 
				System.out.println("Failed to move the file"); 
			} 

		}


	}
}
