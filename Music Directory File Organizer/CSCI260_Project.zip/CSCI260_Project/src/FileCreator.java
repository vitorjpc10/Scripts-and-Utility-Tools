//This class is simply a tool to create dummy data to use on the project


import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

public class FileCreator 
{


	public static void main(String args[]) throws IOException
	{
		
		//If I wanted to insert a string at the first and second line of the text file accordingly
		//List<String> lines = Arrays.asList("", "");
		
		//creates the file and names it
			//java.nio.file.Path file = Paths.get("Guitar2.txt");
		
		//writes in the file based on what you inserted on the variable lines
			//Files.write(file, lines, StandardCharsets.UTF_8);
		
		
		//List<String> lines = Arrays.asList("", "");
		//java.nio.file.Path file = Paths.get("C#Major.txt");
		//Files.write(file, lines, StandardCharsets.UTF_8);
		
		
		
		
		int loopCount = 2;
		String textFileName = "Harmonica";
		java.nio.file.Path file = null;
		List<String> lines = Arrays.asList("", "");
		
		for(int i = 0; i < loopCount; i++)
		{
			
			if (i == 0)
			{
			file = Paths.get(textFileName+".txt");
			Files.write(file, lines, StandardCharsets.UTF_8);
			}
			else
			{
				file = Paths.get(textFileName+i+".txt");
				Files.write(file, lines, StandardCharsets.UTF_8);	
			}
			
			
		}
		

	}
}
