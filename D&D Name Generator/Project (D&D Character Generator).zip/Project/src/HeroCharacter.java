import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

public class HeroCharacter extends GameCharacter {

	private	String[] heroNames;
	private String[] heroRaces = {"Dragonborn", "Dwarf", "Eladrin", "Elf", "Human", "Halfling", "Tiefling"};
	private String[] heroGenders = {"Male", "Female"};

	public String heroRacesToString() {

		return "[Dragonborn, Dwarf, Eladrin, Elf, Human, Halfling, Tiefling]";
	}

	public String heroGendersToString() {
		return "[Male, Female]";
	}

	public HeroCharacter()
	{
		super();
	}

	public HeroCharacter(String name, String race, String gender)
	{

		HeroCharacter.this.setRace(race);
		HeroCharacter.this.setName(name);
		HeroCharacter.this.setGender(gender);

	}

	public void heroCharacterRandomName(String race, String gender)
	{
		//File directory = new File("./");
		 //  System.out.println("The Path is: " + directory.getAbsolutePath());
		
		String properRace = race;
		String properGender = gender;

		//Checks if the first characters for both race and gender are capitalized, if not it does so. 
		if(Character.isLowerCase(properRace.charAt(0)))
			properRace = properRace.substring(0,1).toUpperCase() + properRace.substring(1, properRace.length());
		if(Character.isLowerCase(properGender.charAt(0)))
			properGender = properGender.substring(0,1).toUpperCase() + properGender.substring(1, properGender.length());

		HeroCharacter.this.setRace(properRace);
		HeroCharacter.this.setGender(properGender);

		File txt = new File(".\\src\\" + race + gender + "Names.txt");
		

		try {

			//count number of names in txt file
			int arraySize = this.fileNumCount(txt);

			//set heroName array size to that count
			heroNames = new String[arraySize];

			Scanner sc = new Scanner(txt);
			String name;

			//scans the name, removes the ',', and adds to the array
			for(int i = 0; i < heroNames.length; i++)
			{
				name = sc.next();

				//removes the ','
				String newName = name.replaceFirst(",", "");

				//stores it in the array
				heroNames[i] = newName;
			}

			//creates a random integer number within the heroName array length
			Random rnd = new Random();
			int randomNumber = rnd.nextInt(heroNames.length);

			//System.out.println("The Random Number Is: " + randomNumber);

			//sets the object name variable equal to the name of the random index based on the random integer value
			HeroCharacter.this.setName(heroNames[randomNumber]);
			//System.out.println("The random name is: " + heroNames[randomNumber]);

		} 
		catch (FileNotFoundException e) {

			e.printStackTrace();
		}

	}

	public String[] getHeroRaces() {
		return heroRaces;
	}


	public String[] getHeroGenders() {
		return heroGenders;
	}

	public void HeroCharacterRandomRace(String name, String gender)
	{
		String properName = name;
		String properGender = gender;

		//Checks if the first characters for both name and gender are capitalized, if not it does so. 
		if(Character.isLowerCase(properName.charAt(0)))
			properName = properName.substring(0,1).toUpperCase() + properName.substring(1, properName.length());
		if(Character.isLowerCase(properGender.charAt(0)))
			properGender = properGender.substring(0,1).toUpperCase() + properGender.substring(1, properGender.length());

		HeroCharacter.this.setName(properName);
		HeroCharacter.this.setGender(properGender);

		//creates a random index values between heroRaces array range
		Random rnd = new Random();
		int randomNum = rnd.nextInt(heroRaces.length);

		HeroCharacter.this.setRace(heroRaces[randomNum]);

	}


	public void HeroCharacterRandomRaceAndGender(String name)
	{
		String properName = name;

		//Checks if the first character for name is capitalized, if not it does so. 
		if(Character.isLowerCase(properName.charAt(0)))
			properName = properName.substring(0,1).toUpperCase() + properName.substring(1, properName.length());

		HeroCharacter.this.setName(properName);

		//creates a random index values between heroRaces array range
		Random rndRace = new Random();
		int randomNum1 = rndRace.nextInt(heroRaces.length);

		HeroCharacter.this.setRace(heroRaces[randomNum1]);

		Random rndGender = new Random();
		int randomNum2 = rndGender.nextInt(heroGenders.length);

		HeroCharacter.this.setGender(heroGenders[randomNum2]);

	}




	//create a method to count amount of names from textfile which accepts a filepath as a argument and returns an integer
	private int fileNumCount(File filePath) throws FileNotFoundException
	{
		Scanner sc = new Scanner(filePath);
		int nameCount = 0;

		String nameList = "";

		while(sc.hasNext())
		{
			nameList += sc.next() + " ";
		}

		//System.out.println("namelist  : " + nameList);

		for(int i = 0; i < nameList.length(); i++)
		{
			if(Character.isUpperCase(nameList.charAt(i)))
			{
				nameCount++;
			}
		}

		return nameCount;

	}

	public String toString()
	{
		return "Your Hero is: " + HeroCharacter.this.getName() +", The " + HeroCharacter.this.getGender() + " " + HeroCharacter.this.getRace();
	}



}
