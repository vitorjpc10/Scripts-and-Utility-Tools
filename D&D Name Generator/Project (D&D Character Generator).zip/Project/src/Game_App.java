import java.io.File;
import java.util.Scanner;

public class Game_App {
	public static void main(String[] args) throws InvalidOptionException, InvalidRaceInputException
	{


		/*String filePath = new File("").getAbsolutePath();
		System.out.println(filePath);
		 */

		String name;
		String race;
		String gender;

		HeroCharacter standard = new HeroCharacter();

		Scanner sc = new Scanner(System.in);

		System.out.println("Welcome to the D&D Character Generator!" + '\n');

		boolean repeat = true;

		while(repeat) 
		{
			try {
				System.out.println("Please enter the option number you wish to use:" + '\n' + "[Option: 1] Generates a random name given the race and gender." + '\n' + "[Option: 2] Generates a random race given a name and gender." + '\n' + "[Option: 3] Generates a random race and gender given a name." + '\n');
				int optionNum = sc.nextInt();

				//Checks if option input is within the option range, else throw InvalidOptionException
				if(optionNum < 1 || optionNum > 3)
					throw new InvalidOptionException("The option number is not within range");

				if(optionNum == 1)
				{
					System.out.println("Please enter the desired race you want from the options below:");
					System.out.println(standard.heroRacesToString() + '\n');
					race = sc.next();
					
					//makes initial character capitalized
					race = race.substring(0,1).toUpperCase() + race.substring(1, race.length());
					
					
					int validRace = 0;
					String[] defaultRaces = standard.getHeroRaces();
					
					//checks if race inputed is valid, else throw InvalidRaceInputException
					for(int i = 0; i < defaultRaces.length; i++)
					{	
						if(defaultRaces[i].equals(race))
							validRace ++;	
					}
					
					if(validRace == 0)
						throw new InvalidRaceInputException("This race is not valid");
					
					
					
					System.out.println("Please enter the desired gender you want from the options below:");
					System.out.println(standard.heroGendersToString() + '\n');
					gender = sc.next();
					
					//makes initial character capitalized
					gender = gender.substring(0,1).toUpperCase() + gender.substring(1, gender.length());

					HeroCharacter hero = new HeroCharacter();
					hero.heroCharacterRandomName(race, gender);

					System.out.println(hero);

				}
				else
					if(optionNum == 2)
					{
						System.out.println("Please enter the desired name you want:");
						name =  sc.next();
						
						//makes initial character capitalized
						name = name.substring(0,1).toUpperCase() + name.substring(1, name.length());
						
						System.out.println("Please enter the desired gender you want from the options below:");
						System.out.println(standard.heroGendersToString() + '\n');
						gender = sc.next();
						
						//makes initial character capitalized
						gender = gender.substring(0,1).toUpperCase() + gender.substring(1, gender.length());
						
						HeroCharacter hero = new HeroCharacter();
						hero.HeroCharacterRandomRace(name, gender);

						System.out.println(hero);
					}
					else //option 3
					{
						System.out.println("Please enter the desired name you want:");
						name = sc.next();

						//makes initial character capitalized
						name = name.substring(0,1).toUpperCase() + name.substring(1, name.length());
						
						HeroCharacter hero = new HeroCharacter();
						hero.HeroCharacterRandomRaceAndGender(name);

						System.out.println(hero);
					}

				System.out.println('\n' + "Do you wish to use the D&D Character Generator again? [Y,N]");
				String repeatResponse = sc.next().toLowerCase();

				if(repeatResponse.equals("y"))
					repeat = true;
				else
				{
					repeat = false;
					System.out.println("Thank you for using the D&D Character Generator! See you next time!");
				}

			}
			catch(InvalidOptionException ex)
			{
				System.out.println("The option number you inputed is not within the range, please re-enter your option choice." + '\n');
		
			}
			catch(InvalidRaceInputException x)
			{
				System.out.println('\n' + "The race you just entered is incorrect.");
			}
		}



	}
}
