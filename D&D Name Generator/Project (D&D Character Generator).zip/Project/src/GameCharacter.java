
public abstract class GameCharacter {
	
	private int hp;
	private int mp;
	private String name;
	private String race;
	private String gender;
	
	public GameCharacter()
	{
		hp = 100;
		mp = 100;
		name = "PotatoMan";
		race = "Vegetable";
		gender = "Food";
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public int getMp() {
		return mp;
	}

	public void setMp(int mp) {
		this.mp = mp;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}
	
	 public abstract void heroCharacterRandomName(String race, String gender);
	 
	 public abstract void HeroCharacterRandomRace(String name, String gender);
	 
	 public abstract void HeroCharacterRandomRaceAndGender(String name);
	
	

}
