
public class InvalidOptionException extends Exception{

	public InvalidOptionException(String reason)
	{
		super(reason);
	}
}
