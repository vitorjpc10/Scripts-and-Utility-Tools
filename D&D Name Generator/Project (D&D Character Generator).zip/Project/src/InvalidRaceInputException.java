
public class InvalidRaceInputException extends Exception
{
	public InvalidRaceInputException(String reason)
	{
		super(reason);
	}
}
